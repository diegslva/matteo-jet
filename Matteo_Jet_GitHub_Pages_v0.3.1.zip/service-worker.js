'use strict';
const BUILD = '011d14ddf250';
const PREFIX = `matteo-jet:${new URL(self.registration.scope).pathname}:`;
const CACHE = `${PREFIX}${BUILD}`;
const FILES = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './favicon.svg'];
function report(level, event, error) {
  console[level](JSON.stringify({ level, event, build: BUILD, message: error.message, stack: error.stack }));
}
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES)).then(() => self.skipWaiting()).catch(error => {
    report('error', 'offline_install_failed', error); throw error;
  }));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith(PREFIX) && key !== CACHE).map(key => caches.delete(key))))
    .then(() => self.clients.claim()).catch(error => { report('error', 'offline_activate_failed', error); throw error; }));
});
self.addEventListener('fetch', event => {
  const request = event.request, url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || !url.href.startsWith(self.registration.scope)) return;
  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(async error => {
      const cached = await caches.match(new URL('./index.html', self.registration.scope).href);
      if (cached) { report('warn', 'rede_indisponivel_usando_cache_local', error); return cached; }
      report('error', 'offline_navigation_failed', error); throw error;
    }));
  } else {
    event.respondWith(caches.match(request).then(cached => cached || fetch(request)).catch(error => {
      report('error', 'offline_asset_failed', error); throw error;
    }));
  }
});
